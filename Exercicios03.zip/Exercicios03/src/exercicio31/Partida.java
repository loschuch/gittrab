package exercicio31;

public class Partida {

    private String tlocal, tvisitante;
    private int golstl, golstv;
    public boolean flag;

    public Partida(String timelocal, String timevisitante) {
        this.tlocal = timelocal;
        this.tvisitante = timevisitante;
        this.flag = false;
    }

    public String getTlocal() {
        return tlocal;
    }

    public String getTvisitante() {
        return tvisitante;
    }

    public int getGolstl() {
        return golstl;
    }

    public int getGolstv() {
        return golstv;
    }

    public void setGols(int golstlocal, int golstvisitante) {
        this.golstl = golstlocal;
        this.golstv = golstvisitante;
        this.flag = true;
    }

    public boolean foiRealizada() {
        if (flag == true) {
            return true;
        } else {
            return false;
        }
    }

    public String exibePartida() {
        if (flag == true) {
            return this.tlocal + " " + this.golstl + " X " + this.golstv + " " + this.tvisitante;
        } else {
            return "Partida ainda nao foi realizada";
        }
    }

    public String obtemResultado() {
        if (flag == true) {
            if (this.golstl > this.golstv) {
                return this.tlocal;
            } else if (this.golstl < this.golstv) {
                return this.tvisitante;
            } else if (this.golstl == this.golstv) {
                return "Empate";
            }

        }
        return "Partida nao Realizada";

    }

    public int numeroPontos(int x) {
        if (flag == true) {
            String result = obtemResultado();
            int ptsl = 0, ptsv = 0;
            if (result.equals(this.tlocal)) {
                ptsl = 3;
            } else if (result.equals(this.tvisitante)) {
                ptsv = 3;
            } else {
                ptsl = 1;
                ptsv = 1;
            }
            if (x == 1) {
                return ptsl;
            } else {
                return ptsv;
            }
        } else {
            return -1;
        }
    }
    
    public int saldoDeGols(int sgtime) {
        if (this.flag == true) {
            if (sgtime == 1) {
                return this.golstl - this.golstv;
            } else {
                return this.golstv - this.golstl;
            }

        } else {
            return 1000;
        }
    }
}
